import json, subprocess, sys, pathlib
ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import tts_bakeoff as t

def test_cer():
    assert t.cer("안녕하세요", "안녕하세요") == 0
    assert t.cer("안녕하세요", "안녕하세") > 0
    assert t.cer("", "x") == 0.0

def test_dummy_run(tmp_path):
    r = subprocess.run([sys.executable, str(ROOT / "tts_bakeoff.py"), "--engine", "dummy", "--limit", "5", "--out", str(tmp_path)], capture_output=True, text=True)
    assert r.returncode == 0, r.stderr
    s = json.load(open(tmp_path / "dummy_summary.json"))
    assert s["n"] == 5 and s["rtf_mean"] > 0
    assert list((tmp_path / "dummy").glob("*.wav"))

def test_summarize(tmp_path):
    subprocess.run([sys.executable, str(ROOT / "tts_bakeoff.py"), "--engine", "dummy", "--limit", "3", "--out", str(tmp_path)], check=True, capture_output=True)
    r = subprocess.run([sys.executable, str(ROOT / "scripts/summarize.py"), str(tmp_path)], capture_output=True, text=True)
    assert "dummy" in r.stdout and "OK" in r.stdout
