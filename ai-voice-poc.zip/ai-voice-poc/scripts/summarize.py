#!/usr/bin/env python3
"""Aggregate out/*_summary.json -> markdown table + GPU decision hint (dev design V1.2 14.2). Usage: summarize.py out/ [--limit-min 30]"""
import argparse, glob, json, os
ap = argparse.ArgumentParser(); ap.add_argument("out"); ap.add_argument("--limit-min", type=float, default=30.0)
a = ap.parse_args()
rows = [json.load(open(p, encoding="utf-8")) for p in sorted(glob.glob(os.path.join(a.out, "*_summary.json")))]
print("| engine | machine | cpus | load_s | RTF mean | RTF p95 | peak RSS MB | CER | 10min audio -> min |\n|---|---|---|---|---|---|---|---|---|")
for r in rows:
    print(f"| {r['engine']} | {r['machine']} | {r['cpus']} | {r['load_s']} | {r['rtf_mean']} | {r['rtf_p95']} | {r['peak_rss_mb']} | {r.get('cer_mean')} | {r['est_min_for_10min_audio']} |")
print()
for r in rows:
    m = r["est_min_for_10min_audio"]
    v = "OK (CPU 처리 한도 이내)" if m is not None and m <= a.limit_min else "한도 초과 -> GPU 검토(품질·감정 청취 결과와 함께 판정)"
    print(f"- {r['engine']}: {m}분 / 한도 {a.limit_min}분 -> {v}")
print("\n주의: 속도 판정 입력일 뿐입니다. 감정·자연스러움은 블라인드 청취로 별도 판정. 실서버(A1) 실측이 최종.")
