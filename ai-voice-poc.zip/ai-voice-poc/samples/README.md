# samples (공개 저장소에 음성 파일을 올리지 마세요)
- `ref.wav` : 3~10초 한국어 음성(본인 또는 동의받은 음성)
- `ref.txt` : ref.wav의 정확한 전사
`.gitignore`가 이 폴더의 음성 파일을 제외합니다. GitHub Actions에서는 Secrets(`REF_AUDIO_B64`, `REF_TEXT`)로 전달합니다.
