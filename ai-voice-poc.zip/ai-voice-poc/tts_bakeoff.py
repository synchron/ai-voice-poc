#!/usr/bin/env python3
"""TTS bake-off harness (CPU/GPU PoC): RTF, peak RSS, optional CER via faster-whisper re-transcription.
python tts_bakeoff.py --engine qwen3-0.6b --ref samples/ref.wav --ref-text "..." --sentences data/sentences_ko.txt --cer --out out
Engines are plug-ins (ENGINES). 'dummy' needs no model (harness/CI test).
Real-engine code follows public READMEs and is UNVERIFIED until run [검증필요]."""
import argparse, csv, json, os, platform, re, resource, statistics, sys, time, wave
import numpy as np

DEFAULT_SENTENCES = ["안녕하세요, 오늘 날씨가 정말 좋네요.", "정말요? 믿을 수가 없어요!", "그 소식을 듣고 너무 슬펐어요.",
                     "지금 당장 여기서 나가!", "조용히 해. 아무도 모르게 움직여야 해.", "와, 이거 진짜 대박이다!"]
EMOTIONS = ["neutral", "happy", "sad", "angry", "surprised", "whisper"]

def rss_mb():
    r = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    return r / 1024 / (1024 if sys.platform == "darwin" else 1)

def write_wav(path, audio, sr):
    a = np.asarray(audio, dtype=np.float32).reshape(-1)
    with wave.open(path, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr)
        w.writeframes((np.clip(a, -1, 1) * 32767).astype(np.int16).tobytes())
    return len(a) / sr

class Dummy:
    def __init__(self, a): pass
    def synth(self, text, emotion, ref, ref_text):
        time.sleep(0.01); sr = 24000; n = int(sr * len(text) * 0.1)
        return np.sin(np.linspace(0, 440 * 2 * np.pi * len(text) * 0.1, n)) * 0.1, sr

class Qwen3:  # README-based; verify API names on first run [검증필요]
    def __init__(self, a):
        import torch
        from qwen_tts import Qwen3TTSModel
        size = "0.6B" if "0.6" in a.engine else "1.7B"
        dev = "cuda:0" if torch.cuda.is_available() and not a.cpu else "cpu"
        self.m = Qwen3TTSModel.from_pretrained(f"Qwen/Qwen3-TTS-12Hz-{size}-Base", device_map=dev,
                                               dtype=torch.bfloat16 if dev != "cpu" else torch.float32)
    def synth(self, text, emotion, ref, ref_text):
        wavs, sr = self.m.generate_voice_clone(text=text, language="Korean", ref_audio=ref, ref_text=ref_text)
        return wavs[0], sr

ENGINES = {"dummy": Dummy, "qwen3-0.6b": Qwen3, "qwen3-1.7b": Qwen3}  # add cosyvoice3/xtts with same synth() signature

def cer(ref, hyp):
    n = lambda s: re.sub(r"[\s\W_]+", "", s)
    r, h = n(ref), n(hyp)
    if not r: return 0.0
    d = list(range(len(h) + 1))
    for i, rc in enumerate(r, 1):
        p, d[0] = d[0], i
        for j, hc in enumerate(h, 1):
            p, d[j] = d[j], min(d[j] + 1, d[j - 1] + 1, p + (rc != hc))
    return d[len(h)] / len(r)

def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--engine", default="dummy", choices=ENGINES); ap.add_argument("--ref"); ap.add_argument("--ref-text", default="")
    ap.add_argument("--out", default="out"); ap.add_argument("--sentences"); ap.add_argument("--limit", type=int, default=0, help="max total utterances")
    ap.add_argument("--cer", action="store_true"); ap.add_argument("--cpu", action="store_true")
    ap.add_argument("--threads", type=int, default=0)
    a = ap.parse_args(argv)
    if a.threads:
        try:
            import torch; torch.set_num_threads(a.threads)
        except ImportError: pass
    sents = [l.strip() for l in open(a.sentences, encoding="utf-8") if l.strip()] if a.sentences else DEFAULT_SENTENCES
    d = os.path.join(a.out, a.engine); os.makedirs(d, exist_ok=True)
    t0 = time.time(); eng = ENGINES[a.engine](a); load_s = time.time() - t0
    stt = None
    if a.cer:
        from faster_whisper import WhisperModel
        stt = WhisperModel("large-v3-turbo", device="cpu", compute_type="int8")
    jobs = [(e, i, s) for e in EMOTIONS for i, s in enumerate(sents)]
    if a.limit:  # spread across emotions so a small run still covers all of them
        jobs = sorted(jobs, key=lambda j: (j[1], EMOTIONS.index(j[0])))[:a.limit]
    rows = []
    for emo, i, s in jobs:
        t = time.time(); audio, sr = eng.synth(s, emo, a.ref, a.ref_text); el = time.time() - t
        p = os.path.join(d, f"{emo}_{i:02d}.wav"); dur = write_wav(p, audio, sr)
        row = dict(emotion=emo, idx=i, text=s, synth_s=round(el, 3), audio_s=round(dur, 3), rtf=round(el / dur, 3) if dur else None, rss_mb=round(rss_mb()))
        if stt:
            segs, _ = stt.transcribe(p, language="ko"); row["cer"] = round(cer(s, "".join(x.text for x in segs)), 3)
        rows.append(row); print(row, flush=True)
    with open(os.path.join(a.out, f"{a.engine}_results.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, list(rows[0])); w.writeheader(); w.writerows(rows)
    rtfs = [r["rtf"] for r in rows if r["rtf"]]
    ta, ts = sum(r["audio_s"] for r in rows), sum(r["synth_s"] for r in rows)
    summ = dict(engine=a.engine, machine=platform.machine(), cpus=os.cpu_count(), load_s=round(load_s, 1), n=len(rows),
                rtf_mean=round(statistics.mean(rtfs), 3), rtf_p95=round(sorted(rtfs)[int(.95 * (len(rtfs) - 1))], 3),
                peak_rss_mb=round(rss_mb()), total_audio_s=round(ta, 1), total_synth_s=round(ts, 1),
                est_min_for_10min_audio=round(10 * ts / ta, 1) if ta else None,
                cer_mean=round(statistics.mean(r["cer"] for r in rows), 3) if stt else None)
    json.dump(summ, open(os.path.join(a.out, f"{a.engine}_summary.json"), "w"), indent=1); print(summ)

if __name__ == "__main__":
    main()
