# ai-voice-poc
AI Voice Platform의 TTS(Qwen3-TTS) 사전 검증 하네스. 개발설계서 V1.2 14절 PoC용.

```
tts_bakeoff.py        RTF·피크 RSS·CER 측정 (엔진 플러그인)
scripts/summarize.py  결과 표 + CPU 30분 판정 입력
data/sentences_ko.txt 한국어 30문장 (x 감정 6 = 최대 180 발화)
notebooks/colab_poc.ipynb  Colab 실행 노트북
.github/workflows/    ci.yml(테스트, x86+ARM), arm-poc.yml(ARM 실측, 수동 실행)
tests/                하네스 단위 테스트 (모델 불필요)
```
빠른 시작: `pip install numpy pytest && pytest -q` → `python tts_bakeoff.py --engine dummy --limit 5`.
실제 측정은 `PoC 소스패키지·검증 가이드`를 따르세요. **음성 샘플은 저장소에 커밋하지 않습니다.**
Qwen3 호출부는 공개 README 기준이며 실행 전 미검증입니다.
